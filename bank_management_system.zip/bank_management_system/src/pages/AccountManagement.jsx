import React, { useState, useEffect } from 'react';

function AccountManagement() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [initBalance, setInitBalance] = useState(0);
  const [accountNo, setAccountNo] = useState('');
  const [accountInfo, setAccountInfo] = useState(null);

  // Function to create an account
  const createAccount = async () => {
    try {
      const response = await fetch('/api/create-acc', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, initBalance }),
      });

      if (response.status === 201) {
        const data = await response.json();
        setAccountNo(data.accountNo);
      } else {
        console.error('Account creation failed');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // Function to retrieve account information
  const getAccountInfo = async () => {
    try {
      const response = await fetch(`/api/acc-info/${accountNo}`);
      if (response.status === 200) {
        const data = await response.json();
        setAccountInfo(data);
      } else {
        console.error('Account information retrieval failed');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  useEffect(() => {
    if (accountNo) {
      getAccountInfo();
    }
  }, [accountNo]);

  return (
    <div>
      <h2>Account Management</h2>
      <div>
        <h3>Create Account</h3>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="number"
          placeholder="Initial Balance"
          value={initBalance}
          onChange={(e) => setInitBalance(e.target.value)}
        />
        <button onClick={createAccount}>Create Account</button>
      </div>
      {accountNo && (
        <div>
          <h3>Account Information</h3>
          <p>Account Number: {accountNo}</p>
          <button onClick={getAccountInfo}>Get Account Info</button>
          {accountInfo && (
            <div>
              <h4>Account Details</h4>
              <p>Name: {accountInfo.holderName}</p>
              <p>Email: {accountInfo.holderEmail}</p>
              <p>Balance: {accountInfo.balance}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default AccountManagement;
