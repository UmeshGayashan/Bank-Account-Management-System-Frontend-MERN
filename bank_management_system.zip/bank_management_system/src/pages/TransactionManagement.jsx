import React, { useState } from 'react';

function TransactionManagement() {
  const [accountNo, setAccountNo] = useState('');
  const [amount, setAmount] = useState(0);
  const [receiverAccountNo, setReceiverAccountNo] = useState('');
  const [transactions, setTransactions] = useState([]);

  // Function to retrieve transactions for an account
  const getTransactions = async () => {
    try {
      const response = await fetch(`/api/get/${accountNo}`);
      if (response.status === 200) {
        const data = await response.json();
        setTransactions(data);
      } else {
        console.error('Error while fetching transactions');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // Function to perform a deposit
  const deposit = async () => {
    try {
      const response = await fetch('/api/deposit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount, accountNo }),
      });

      if (response.status === 200) {
        // Deposit successful, update transaction history
        getTransactions();
      } else {
        console.error('Deposit failed');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // Function to perform a withdrawal
  const withdraw = async () => {
    try {
      const response = await fetch('/api/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount, accountNo }),
      });

      if (response.status === 200) {
        // Withdrawal successful, update transaction history
        getTransactions();
      } else {
        console.error('Withdrawal failed');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // Function to perform a transfer
  const transfer = async () => {
    try {
      const response = await fetch('/api/transfer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ senderAccountNo: accountNo, receiverAccountNo, amount }),
      });

      if (response.status === 200) {
        // Transfer successful, update transaction history
        getTransactions();
      } else {
        console.error('Transfer failed');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div>
      <h2>Transaction Management</h2>
      <div>
        <h3>Account Details</h3>
        <input
          type="text"
          placeholder="Account Number"
          value={accountNo}
          onChange={(e) => setAccountNo(e.target.value)}
        />
        <button onClick={getTransactions}>Get Transactions</button>
      </div>
      <div>
        <h3>Deposit</h3>
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button onClick={deposit}>Deposit</button>
      </div>
      <div>
        <h3>Withdraw</h3>
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button onClick={withdraw}>Withdraw</button>
      </div>
      <div>
        <h3>Transfer</h3>
        <input
          type="text"
          placeholder="Receiver Account Number"
          value={receiverAccountNo}
          onChange={(e) => setReceiverAccountNo(e.target.value)}
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button onClick={transfer}>Transfer</button>
      </div>
      {transactions.length > 0 && (
        <div>
          <h3>Transaction History</h3>
          <ul>
            {transactions.map((transaction) => (
              <li key={transaction._id}>{transaction.transType} - {transaction.amount}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default TransactionManagement;
