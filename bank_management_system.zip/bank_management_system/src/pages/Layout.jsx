import React from 'react'
import { Outlet } from 'react-router-dom'
import { Navbar } from '../components/Navbar'

function Layout() {
  return (
    <main className='container'>
        <Navbar/>
        <Outlet/>
        <p>futter</p>
    </main>
  )
}

export default Layout